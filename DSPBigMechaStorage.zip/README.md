# DSP Big Mecha Storage
Increase the size of the fuel chamber and warper slot of Mecha.<br>
This don't affect achievements or milestones. <br>
<br>
メカの燃焼室や空間歪曲器のスロットのサイズが大きくなります。<br>
実績やマイルストーンには影響しません。<br>
<br>
## Features　特徴
Increase the size of the fuel chamber and warper slot of Mecha. <br>
You cannot specify the size.<br>
<br>
メカの燃焼室や空間歪曲器のスロットのサイズが大きくなります。<br>
サイズを指定することはできません。<br>
<br>
## How to install　インストール方法
1. Install BepInEx<br>
2. Drag DSPBigMechaStorage.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins or /plugins/DSPBigMechaStorage<br>
<br>
1. BepInExをインストールします。<br>
2. DSPBigMechaStorage.dllをsteamapps/common/Dyson Sphere Program/BepInEx/pluginsか/plugins/DSPBigMechaStorageに配置します。<br>
<br>
## Contact 問い合わせ先
If you have any problems or suggestions, please contact DISCORD MSP Modding server **Appun#8284**.<br>
不具合、改善案などありましたら、DISCORD「DysonSphereProgram_Jp」サーバー**Appun#8284**までお願いします。<br>
<br>
## Change Log　更新履歴
### v1.0.3
- Supported the game version 0.9.24.11286. ゲームバージョン0.9.24.11286に対応しました。
- Published in GitHub. GitHubに公開しました。
### v1.0.2
- Reverted the 1.0.2 fix. Now same as 1.0.0.　1.0.1に問題があったため修正しました。1.0.0と同じです。
### v1.0.1
- reduce the load 負荷を軽減しました。
### v1.0.0
- released リリースしました。
